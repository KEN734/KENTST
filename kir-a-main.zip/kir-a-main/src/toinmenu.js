const kenmenu = (prefix, pushname) => {
    return `◪ *Comandos do ken*
╔════════════════════
║╭──❉ *MENU DO KEN* ❉── 
║│➸${prefix}prefixo
║│Sobre : esse muda o prefixo
║╰───────────
║╭───────────
║│➸${prefix}block
║│Sobre : esse da block
║╰───────────
║╭───────────
║│➸${prefix}bc
║│Sobre : esse da ban no numero usa naum
║╰───────────
║╭───────────
║│➸${prefix}bcgc
║│Sobre : esse da ban no numero de um geito diferente
║╰───────────
║╭───────────
║│➸${prefix}clearall
║│Sobre : esse limpa todas conversa do bot
║╰───────────
╠════════════════════
║ TITIO PAIN O MAIS BRABOR
╚════════════════════
`

}

exports.kenmenu = kenmenu