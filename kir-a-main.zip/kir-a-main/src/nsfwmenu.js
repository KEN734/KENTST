const nsfwmenu = (prefix, pushname) => {
    return `Oiin resumindo aqui e o menu NSFW
╔════════════════════
║╭──❉ *NSFW MENU* ❉── 
║│➸ ${prefix}nsfwbobs
║│Sobre : para ser sincero e tudo hentai
║╰───────────
║╭───────────
║│➸ ${prefix}randomhentaio
║│Sobre : para ser sincero e tudo hentai
║╰───────────
║╭───────────
║│➸ ${prefix}nsfwtrap
║│Sobre : para ser sincero e tudo hentai
║╰───────────
║╭───────────
║│➸ ${prefix}nsfwthighs
║│Sobre : para ser sincero e tudo hentai
║╰───────────
║╭───────────
║│➸ ${prefix}nsfwarmpits
║│Sobre : para ser sincero e tudo hentai
║╰───────────
║╭───────────
║│➸ ${prefix}nsfwfeets
║│Sobre : para ser sincero e tudo hentai
║╰───────────
║╭───────────
║│➸ ${prefix}nsfwahegao
║│Sobre : para ser sincero e tudo hentai
║╰───────────
║╭───────────
║│➸ ${prefix}nsfwsidebobs
║│Sobre : para ser sincero e tudo hentai
║╰───────────
║╭───────────
║│➸ ${prefix}nsfwbelly
║│Sobre : para ser sincero e tudo hentai
║╰───────────
║╭───────────
║│➸ ${prefix}nsfwass
║│Sobre : para ser sincero e tudo hentai
║╰───────────
╠════════════════════
║ KEN DOMINA
╚════════════════════

  _obs para usar esses comandos ative o menu NSFW_\n _Digite_\n ${prefix}*nsfw 1*`



}

exports.nsfwmenu = nsfwmenu