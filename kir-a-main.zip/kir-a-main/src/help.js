const help = (prefix,pushname2, user, limitt) => {
	return `	
❉──────────❉

   「 *KEN BOT* 」

❉──────────❉
╔════════════════════
║╭──❉ *INFORMAÇÕES DO USUARIO* ❉──
║│➸NOME DO USUARIO : *${pushname2}*
║│➸REGISTRADO :  *${user.length}* Se n use *${prefix}rg nome|idade*
║│➸LIMITE DE COMANDOS : *${limitt}*
║╰───────────    
╚════════════════════
╔════════════════════
║╭──❉ *INFORMAÇÕES* ❉──
║│➸ Prefix: 「  ${prefix}  」
║│➸ Criador : *KEN*
║│➸ Numero do meu criador: https://wa.me/557999076521
║╰───────────    
╠════════════════════
║╭──❉ *STICKERS* ❉──
║│➸ ${prefix}sticker OU ${prefix}stickergif
║│Sobre : O comando  ${prefix}sticker OU ${prefix}stickergif faz figurinha
║╰───────────
║╭───────────
║│➸${prefix}toimg
║│Sobre : O comando ${prefix}toimg e para converter stickers  em fotos 
║╰───────────
║╭───────────
║│➸${prefix}tomp3
║│Sobre : o comando ${prefix}tomp3 e para converter videos em audio
║╰───────────
╠════════════════════
║╭──❉ *PREMIUM* ❉──
║│➸${prefix}play
║│Sobre : esse comando ${prefix}play e para abaixar musica
║╰───────────
║╭───────────
║│➸${prefix}joox
║│Sobre : esse comando ${prefix}joox e para abaixar musica/videos
║╰───────────
║╭───────────
║│➸${prefix}ytmp3
║│Sobre : esse comando ${prefix}ytmp3 e para abaixar musica
║╰───────────
║╭───────────
║│➸${prefix}snack
║│Sobre : esse comando ${prefix}snack e para abaixar videos de algum lugar ai
║╰───────────
║╭───────────
║│➸${prefix}ytmp4
║│Sobre : esse comando ${prefix}ytmp4 e para abaixar videos com a url
║╰───────────
║╭───────────
║│*EM BREVE MAIS FUNÇOES PREMIUM*
║│
║╰───────────
╠════════════════════
║╭──❉ *AUDIO* ❉──
║│➸${prefix}tts
║│Sobre : esse comando e para o bot falar\n║│exemplo : ${prefix}tts pt pain bot
║╰───────────
╠════════════════════
║╭──❉ *FOTOS E OUTRAS COISINHAS* ❉──
║│➸${prefix}loli
║│Sobre : esse ai e pros lolicon kkkkk
║╰───────────
║╭───────────
║│➸${prefix}shota
║│Sobre : as vezes vai mais e uma foto de um menino
║╰───────────
║╭───────────
║│➸${prefix}imagem
║│Sobre : esse pesquisa qual quer foto do pinterest
║╰───────────
║╭───────────
║│➸${prefix}neko
║│Sobre : esse e pros lolicon que gosta\n║│da oni-chan com rabinho e orelha de gato
║╰───────────
╠════════════════════
║╭──❉ *OUTROS* ❉──
║│➸ ${prefix}meulink
║│Sobre : mando o wa.me/Seu numero
║╰───────────
║╭───────────
║│➸ ${prefix}travazap
║│Sobre : so pelo nome vcs ja sabem kkk
║╰───────────
║╭───────────
║│➸ ${prefix}afk
║│Sobre : esse comando e pra quele amigo corno que n deixa vc quieto
║╰───────────
║╭───────────
║│➸ ${prefix}tempo
║│Sobre : esse negocio ai nem sei pra que serve ksksksksks
║╰───────────
╠════════════════════
║╭──❉ *SOBRE* ❉──
║│➸ ${prefix}info
║│Sobre : isso e para saber as info do bot
║╰───────────
║╭───────────
║│➸ ${prefix}blocklist
║│Sobre : lista de bloqueados do bot
║╰───────────
║╭───────────
║│➸  ${prefix}ping
║│Sobre : o ping do bot
║╰───────────
╠════════════════════
║╭──❉ *ESSE AGORA E SO PRO TIO PAIN* ❉──
║│➸  ${prefix}prefixo
║│Sobre : muda o prefixo
║╰───────────
║╭───────────
║│➸ ${prefix}block
║│Sobre : bloquea a pessoa
║╰───────────
║╭───────────
║│➸ ${prefix}bc
║│Sobre : brodcast esamerda da ban no bot usa n
║╰───────────
║╭───────────
║│➸ ${prefix}bcgc
║│Sobre : brodcast diferenciado esamerda da ban no bot usa n
║╰───────────
║╭───────────
║│➸ ${prefix}clone
║│Sobre : clona a foto do amigo
║╰───────────
║╭───────────
║│➸ ${prefix}clearall
║│Sobre : limpa tudo do chat do bot
║╰───────────
╠════════════════════
║╭──❉ *OUTROS MENU* ❉──
║│➸ ${prefix}menuadmin
║╰───────────
║╭───────────
║│➸ ${prefix}toinmenu
║╰───────────
║╭───────────
║│➸ ${prefix}nsfwmenu
║╰───────────
║╭───────────
║│➸ ${prefix}idiomas
║╰───────────
╠════════════════════
║ GIT REMODELADA BY KEN 
╚════════════════════
`
}

exports.help = help
