const menuadmin = (prefix, pushname) => {
 return `oiin usadores de zape zape aqui e o menu dos admins
 _obs para o bot executar esses comandos e nescessario dar adm para o bot_
 
╔════════════════════
║╭──❉ *MENU ADMS* ❉── 
║│➸${prefix}opengc
║│Sobre : esse comando abre o grupo
║╰───────────
║╭───────────
║│➸ ${prefix}closegc
║│Sobre : esse comando fecha o grupo
║╰───────────
║╭───────────
║│➸${prefix}promover
║│Sobre : esse promove um membro comum em ademir
║╰───────────
║╭───────────
║│➸${prefix}rebaixar
║│Sobre : esse comando rebaixa um adm a membro comum
║╰───────────
║╭───────────
║│➸${prefix}tagall
║│Sobre : esse e pra chama geral kkk
║╰───────────
║╭───────────
║│➸${prefix}tagall2
║│Sobre : esse e pra chama geral kkk
║╰───────────
║╭───────────
║│➸${prefix}tagall3
║│Sobre : esse e pra chama geral kkk
║╰───────────
║╭───────────
║│➸${prefix}tagall4
║│Sobre : esse e pra chama geral kkk
║╰───────────
║╭───────────
║│➸${prefix}tagall5
║│Sobre : esse e pra chama geral kkk
║╰───────────
║╭───────────
║│➸${prefix}add
║│Sobre : esse adiciona um ctt no grupo\n║│exemplo : ${prefix}add 551199xxxxxxxx
║╰───────────
║╭───────────
║│➸${prefix}kick
║│Sobre : esse da o ban no cara chato\n║│exemplo : ${prefix}kick @tagdocomedia
║╰───────────
║╭───────────
║│➸${prefix}listadmins
║│Sobre : esse comando e o que mostra os ademir
║╰───────────
║╭───────────
║│➸${prefix}linkgroup
║│Sobre : esse e pra mandar o link do grupo
║╰───────────
║╭───────────
║│➸${prefix}sair
║│Sobre : esse e pra o bot sair do grupo
║╰───────────
║╭───────────
║│➸${prefix}bemvindo
║│Sobre : esse e para ativar a o bem vindo aos que entra por link\n║│exemplo : ${prefix}bemvindo 1 e para desativar e so botar o 0
║╰───────────
║╭───────────
║│➸ ${prefix}nsfw
║│Sobre : esse bota o nsfw 1 pra desativar 0 esse e o de hentai
║╰───────────
║╭───────────
║│➸${prefix}leveling
║│Sobre : esse e para ativar o level dos membros
║╰───────────
║╭───────────
║│➸${prefix}level
║│Sobre : esse e para ver o level 
║╰───────────
║╭───────────
║│➸${prefix}delete
║│Sobre : esse e para  o bot deletar o que ele mandou
║╰───────────
║╭───────────
║│➸${prefix}simih
║│Sobre : nunca ative isso namoral chato pra caramba
║╰───────────
║╭───────────
║│➸${prefix}ownergroup
║│Sobre : esse e para saber quem e o dono do grupo
║╰───────────
╠════════════════════
║ KEN DOMINA
╚════════════════════
 `


}

exports.menuadmin = menuadmin