// menu fitur bot
const help = (prefix, instagram, yt, name, pushname2, user, limitt, uptime, jam, tanggal) => { 
	return `
╭──────「 *REGULATION ${name}* 」
┴
┣⊱  \`\`\`NOME DO USUARIO:\`\`\` *${pushname2}*
┣⊱  \`\`\`VERIFICADO:\`\`\` ✅
┣⊱  \`\`\`LIMITE:\`\`\` *${limitt} DIARIO*
┣⊱  \`\`\`ATIVO:\`\`\` ${kyun(uptime)}
┣⊱  \`\`\`JAM:\`\`\` *${jam} WIB*
┣⊱  \`\`\`mes:\`\`\` *${tanggal}*
┣⊱  \`\`\`VERSAO:\`\`\` *3.0.0*
┣⊱  \`\`\`USE TERDAFTAR:\`\`\` *${user.length} User*
┣⊱  ❌ *SPAM*
┣⊱  ❌ *CALL & VC*
┣⊱  \`\`\`*BOT FEITO BY KEN*\`\`\`
┬
╰────────────────────────


╭──────「 *SOBRE ${name}* 」
┴
│➻ *${prefix}report lapor bug*
│➻ *${prefix}info*
│➻ *${prefix}donasi*
│➻ *${prefix}owner*
│➻ *${prefix}speed*
│➻ *${prefix}daftar*
│➻ *${prefix}totaluser*
│➻ *${prefix}grouplist*
│➻ *${prefix}blocklist*
│➻ *${prefix}banlist*
│➻ *${prefix}premiumlist*
│➻ *${prefix}bahasa*
┬
╰────────────────────────


͏͏͏͏͏͏͏͏͏͏͏͏͏͏╭──────「 *MIDIA DOWNLOADER* 」
┴
│➻ *${prefix}tiktokstalk username*
│➻ *${prefix}igstalk _farhan_xcode7*
│➻ *${prefix}instavid link valid*
│➻ *${prefix}instaimg link valid*
│➻ *${prefix}instastory username*
│➻ *${prefix}ssweb url*
│➻ *${prefix}url2img Url*
│➻ *${prefix}tiktok*
│➻ *${prefix}fototiktok*
│➻ *${prefix}memeindo*
│➻ *${prefix}kbbi*
│➻ *${prefix}wait*
│➻ *${prefix}trendtwit*
│➻ *${prefix}google berita terkini*
┬
╰────────────────────────


╭──────「 *CRIADOR MENU* 」
┴
│➻ *${prefix}quotemaker tx/wtrmk/tema*
│➻ *${prefix}nulis nama/kelas/text*
│➻ *${prefix}nulis Fxc7/Bot*
│
│➻ *${prefix}tahta BRUXINHO*
│➻ *${prefix}croman BRUXINHL dan BOT*
│➻ *${prefix}clove BRUXINHO*
│➻ *${prefix}cparty BRUXINHO*
│➻ *${prefix}csky BRUXINHO*
│➻ *${prefix}tts id Haii*
│➻ *${prefix}ttp BRUXINHO [ERRO]*
│➻ *${prefix}cballon BRUXINHO*
│➻ *${prefix}cpaper BRUXINHO*
│➻ *${prefix}slide BRUXINHO BOT WA*
│
│➻ *${prefix}stiker*
│➻ *${prefix}gifstiker*
│➻ *${prefix}toimg*
│➻ *${prefix}img2url*
│➻ *${prefix}tomp3*
│➻ *${prefix}ocr*
┬
╰──────────────────────────


╭───────「 *𝐴𝑃𝐸𝑁𝐴𝑆 𝐸𝑀 𝐺𝑅𝑈𝑃𝑂* 」
┴
│➻ *${prefix}modeanime On/Off*
│➻ *${prefix}naruto*
│➻ *${prefix}minato*
│➻ *${prefix}boruto*
│➻ *${prefix}hinata*
│➻ *${prefix}sakura*
│➻ *${prefix}sasuke*
│➻ *${prefix}toukachan*
│➻ *${prefix}rize*
│➻ *${prefix}akira*
│➻ *${prefix}itori*
│➻ *${prefix}kurumi*
│➻ *${prefix}miku*
│➻ *${prefix}anime*
│➻ *${prefix}animecry*
│➻ *${prefix}neonime*
│➻ *${prefix}animekiss*
┬
╰───────────────────────

╭───────「 *𝐴𝑃𝐸𝑁𝐴𝑆 𝐸𝑀 𝐺𝑅𝑈𝑃𝑂* 」
┴
│➻ *${prefix}welcome On/Off*
│➻ *${prefix}grup buka/tutup*
│➻ *${prefix}antilink on/off*
│➻ *${prefix}ownergrup*
│➻ *${prefix}setpp*
│➻ *${prefix}infogc*
│➻ *${prefix}add 55𝑋𝑋𝑋𝑋𝑋𝑋*
│➻ *${prefix}kick @𝑚𝑎𝑟𝑞𝑢𝑒 𝑜 𝑓𝑑𝑝*
│➻ *${prefix}kicktime @𝑚𝑎𝑟𝑞𝑢𝑒 𝑜 𝑓𝑑𝑝*
│➻ *${prefix}promote @𝑚𝑎𝑟𝑞𝑢𝑒 𝑜 𝑓𝑑𝑝*
│➻ *${prefix}demote @𝑚𝑎𝑟𝑞𝑢𝑒 𝑜 𝑓𝑑𝑝*
│➻ *${prefix}setname*
│➻ *${prefix}setdesc*
│➻ *${prefix}linkgrup*
│➻ *${prefix}tagme*
│➻ *${prefix}hidetag*
│➻ *${prefix}tagall*
│➻ *${prefix}mentionall*
│➻ *${prefix}fitnah*
│➻ *${prefix}listadmin*
┬
╰────────────────────────

╭───────「 *𝐴𝑃𝐸𝑁𝐴𝑆 𝐸𝑀 𝐺𝑅𝑈𝑃𝑂* 」
┴
│➻ *${prefix}nsfw On/Off*
│➻ *${prefix}nsfwloli*
│➻ *${prefix}nsfwblowjob*
│➻ *${prefix}nsfwneko*
│➻ *${prefix}nsfwtrap*
│➻ *${prefix}hentai*
│➻ *${prefix}simih On/Off*
┬
╰────────────────────────


╭──────「 *OUTROS FUN & GAME* 」
┴
│➻ *${prefix}anjing*
│➻ *${prefix}kucing*
│➻ *${prefix}testime*
│➻ *${prefix}hilih*
│➻ *${prefix}apakah*
│➻ *${prefix}kapankah*
│➻ *${prefix}bisakah*
│➻ *${prefix}rate*
│➻ *${prefix}watak*
│➻ *${prefix}hobby*
│➻ *${prefix}infogempa*
│➻ *${prefix}infonomor*
│➻ *${prefix}quotes*
│➻ *${prefix}truth*
│➻ *${prefix}dare*
│➻ *${prefix}katabijak*
│➻ *${prefix}fakta*
│➻ *${prefix}darkjokes*
│➻ *${prefix}bucin*
│➻ *${prefix}pantun*
│➻ *${prefix}katacinta*
│➻ *${prefix}jadwaltvnow*
│➻ *${prefix}hekerbucin*
│➻ *${prefix}katailham*
┬
╰────────────────────────

╭──────「 *OUTROS FUN & GAME* 」
┴
│➻ *${prefix}jarak Banyuwangi/Surabaya*
│➻ *${prefix}translate en/Apa kabar?*
│➻ *${prefix}pasangan Farhan/Iriene*
│➻ *${prefix}gantengcek Farhan*
│➻ *${prefix}cantikcek Iriene*
│➻ *${prefix}artinama Farhan*
│➻ *${prefix}persengay Topan*
│➻ *${prefix}pbucin Farhan*
│➻ *${prefix}bpfont Farhan*
│➻ *${prefix}textstyle FXC7*
│➻ *${prefix}jadwaltv antv*
│➻ *${prefix}lirik melukis senja*
│➻ *${prefix}chord Melukis senja*
│➻ *${prefix}wiki Adolf Hitler*
│➻ *${prefix}brainly pertanyaan*
│➻ *${prefix}resepmasakan rawon*
│➻ *${prefix}map Banyuwangi*
│➻ *${prefix}film Fast and Farious*
│➻ *${prefix}pinterest gambar kucing*
│➻ *${prefix}infocuaca Banyuwangi*
│➻ *${prefix}jamdunia Banyuwangi*
│➻ *${prefix}mimpi Ular*
│➻ *${prefix}infoalamat jalan Banyuwangi*
│➻ *${prefix}playstore WhatsApp*
┬
╰───────────────────────────


╭──────「 *OUTROS FUN & GAME* 」
┴
│➻ *${prefix}asupan*
│➻ *${prefix}tebakgambar*
│➻ *${prefix}caklontong*
│➻ *${prefix}family100*
│➻ *${prefix}calculadora 13*12*
│➻ *${prefix}moddroid lightroom*
│➻ *${prefix}happymod lightroom*
┬
╰────────────────────────

╭──────「 *OUTROS FUN & GAME* 」
┴
│➻ *${prefix}cerpen*
│➻ *${prefix}cersex*
│➻ *${prefix}randombokep*
│➻ *${prefix}pornhub stepMoms*
┬
╰────────────────────────

╭──────「 *SPAM* 」
┴
│➻ *${prefix}jadwalsholat Banyuwangi*
│➻ *${prefix}quran*
│➻ *${prefix}quransurah 1*
┬
╰────────────────────────

╭──────「 *OOUTROS JOGOS DIVERTIDOS* 」
┴
│➻ *${prefix}becrypt string*
│➻ *${prefix}encode64 string*
│➻ *${prefix}decode64 encrypt*
│➻ *${prefix}encode32 string*
│➻ *${prefix}decode32 encrypt*
│➻ *${prefix}encbinary string*
│➻ *${prefix}decbinary encrypt*
│➻ *${prefix}encoctal string*
│➻ *${prefix}decoctal encrypt*
│➻ *${prefix}hashidentifier Encrypt Hash*
│➻ *${prefix}dorking dork*
│➻ *${prefix}pastebin teks*
│➻ *${prefix}tinyurl link*
│➻ *${prefix}bitly link*
┬
╰────────────────────────

╭──────「 *OUTROS FUN & GAME* 」
┴
│➻ *${prefix}spamcall 5579xxxxxxxxx*
│➻ *${prefix}spamsms 5579xxxxxxxx/jumlah*
│➻ *${prefix}spamgmail KENONRABOR@gmail.com*
┬
╰────────────────────────


╭─────────「 *𝑺Ó 𝑷𝑹𝑶𝑷𝑹𝑰𝑬𝑻𝑨𝑹𝑰𝑶* 」
┴
│➻ *${prefix}addprem mentioned*
│➻ *${prefix}removeprem mention*
│➻ *${prefix}setmemlimit*
│➻ *${prefix}setreply*
│➻ *${prefix}setprefix*
│➻ *${prefix}setnamebot*
│➻ *${prefix}setppbot*
│➻ *${prefix}bc*
│➻ *${prefix}bcgc*
│➻ *${prefix}ban*
│➻ *${prefix}unban*
│➻ *${prefix}block*
│➻ *${prefix}unblock*
│➻ *${prefix}clearall*
│➻ *${prefix}delete*
│➻ *${prefix}clone*
│➻ *${prefix}getses*
│➻ *${prefix}leave*
┬
╰────────────────────────


╭────────「 *𝑷𝑹𝑬𝑴𝑰𝑼𝑴 𝑨𝑷𝑬𝑵𝑨𝑺* 」
┴
│➻ *${prefix}playmp3 menepi*
│➻ *${prefix}fb link video*
│➻ *${prefix}snack link snack video*
│➻ *${prefix}ytmp3 link yt [ERROR]*
│➻ *${prefix}ytmp4 link yt [ERROR]*
│➻ *${prefix}joox Monolog Pamungkas*
│➻ *${prefix}smule Link Video Smule*
┬
╰────────────────────────`
}

exports.help = help

// penghitung aktif bot
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik*`
}

// donasi menu
const donasi = (name) => { 
	return `       
╭─────「 *DONASI SEIKHLASNYA* 」
┴
│√ *PULSA: 08311800241*
│√ *OVO : 08311800241*
┬
╰──────「 *BY ${name}* 」

`
}
exports.donasi = donasi

// bahasa list
const bahasa = (prefix) => {
return `
List Bahasa Untuk Command *${prefix}tts*

  af: Afrikaans
  sq: Albanian
  ar: Arabic
  hy: Armenian
  ca: Catalan
  zh: Chinese
  zh-cn: Chinese (Mandarin/China)
  zh-tw: Chinese (Mandarin/Taiwan)
  zh-yue: Chinese (Cantonese)
  hr: Croatian
  cs: Czech
  da: Danish
  nl: Dutch
  en: English
  en-au: English (Australia)
  en-uk: English (United Kingdom)
  en-us: English (United States)
  eo: Esperanto
  fi: Finnish
  fr: French
  de: German
  el: Greek
  ht: Haitian Creole
  hi: Hindi
  hu: Hungarian
  is: Icelandic
  id: Indonesian
  it: Italian
  ja: Japanese
  ko: Korean
  la: Latin
  lv: Latvian
  mk: Macedonian
  no: Norwegian
  pl: Polish
  pt: Portuguese
  pt-br: Portuguese (Brazil)
  ro: Romanian
  ru: Russian
  sr: Serbian
  sk: Slovak
  es: Spanish
  es-es: Spanish (Spain)
  es-us: Spanish (United States)
  sw: Swahili
  sv: Swedish
  ta: Tamil
  th: Thai
  tr: Turkish
  vi: Vietnamese
  cy: Welsh
`
}
exports.bahasa = bahasa

// Limit
const limitend = (pushname2) => {
        return`*maaf ${pushname2} limit hari ini habis*\n*limit di reset setiap jam 12:00 WIB TENGAH MALAM*`
}

const limitcount = (limitCounts) => {
        return`
${limitCounts}
`
}

exports.limitend = limitend
exports.limitcount = limitcount
